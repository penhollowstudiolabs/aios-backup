# Daily Brief — the cron prompt is the executable spec

Live state (8/10): daily brief is cron job `a85b2d174ce5` ("Daily Brief"),
schedule `30 12 * * *` = **5:30 AM PDT**, delivers to Telegram chat
8743718071, models `deepseek/deepseek-v4-flash-0731` via nous. Outputs are
written to `~/.hermes/profiles/alyosha/cron/output/a85b2d174ce5/<ts>.md` and
the delivered brief is also archived in the vault at
`Calendar/Daily Briefs/`. Job details live in
`~/.hermes/profiles/alyosha/cron/jobs.json`.

## The core lesson (8/10)

**The thing that actually runs the brief is the cron job's `prompt` field — not
any spec document.** Avi repeatedly asked across sessions ("add this to the
brief," "I want to add that"), and those asks were being written into spec docs
(`Avi Operating Model - v1`, `AIOS/Current Workboard.md`,
`AIOS/Current Priorities`) — but the cron prompt was **never updated**. So the
vault said one thing and the delivered brief did another. Root failure mode:
treating the spec as the source of truth when the *prompt* is.

Rule: **when Avi asks to add/change the brief, edit the cron job's prompt (via
`hermes cron update` / the cronjob tool) in the same pass — not just the spec.**
Spec docs are design intent; the prompt is the running behavior.

## Minimum briefing design (from Avi Operating Model v1)

The intended daily orientation should contain ONLY:
1. top active commitments;
2. deadlines, appointments, and waiting-on items;
3. **changes or decisions needing Avi's attention**;
4. one recommended next action; and
5. a system-health exception **only when it materially matters**.

**"If nothing needs attention, say so plainly. Do not manufacture activity."** —
this is Avi's own line. A brief that always manufactures urgency is off-spec.

## Compilation-surface role (workboard wording)

"Treat the future daily brief as the intended compilation surface: stable
orientation, only material scheduled-task outputs, one source-linked
patterns-and-connections." It should **cross-link patterns from scheduled-task
outputs**, not just push a vault digest.

## The gentle tap on the shoulder (from the Ideaverse note, 8/05)

The brief may from time to time resurface **one past vibe-chat moment** as a
calm *memory* — reminding Avi of a thread born in the Ideaverse without pushing
it onto the workboard. Not an auto-export (the affirmation firewall still
governs exports). The first brief delivered this tap (8/05); later runs dropped
it.

## Calendar / meeting-protection layer (NOT yet wired — the parked thread)

An operating-model distinction: a briefing gives orientation but does NOT
prevent missed meetings. Meeting protection needs (a) a confirmed authoritative
calendar source, (b) dependable alerts on the device Avi uses, and (c) visible
follow-through for captured-but-incomplete tasks. This is Priority B
(schedule reconciliation) on the workboard — it was deferred ("Avi needs a
sit-down... not before the 12th") and that sit-down **never happened**, so the
brief remained vault-digest-only.

**The dependency cleared 8/08:** Gmail + Google Calendar OAuth for the alyosha
profile is live and read-only verified
(`~/.hermes/profiles/alyosha/google_token.json`). The calendar-grounded brief
is now buildable — a future session can pull the real calendar into the brief
without asking for new access (still respect the operating policy: reads are
free, every write needs per-action Avi approval).

## The gap in one line

The brief is a working **report**, but the **system** it was designed to become
(calendar-grounded, meeting-protecting, cross-linking scheduled outputs) was
parked on a sit-down that never happened — and the dependency blocking that
path is now shipped. When rebuilding, fold the full accumulated design above
into the cron prompt, get Avi's sign-off, and update the prompt.